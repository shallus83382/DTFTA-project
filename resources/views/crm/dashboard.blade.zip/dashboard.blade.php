@extends('layouts.app')

@section('title', 'DTFTA CRM - Dashboard')
@section('page-title', 'Dashboard Overview')

@section('content')


    <div class="cards-grid">
        <div class="card card-blue">
            <div class="card-icon card-icon-clipboard" aria-hidden="true"></div>
            <div class="card-content">
                <h3>Total Orders</h3>
                <p class="card-value">{{ number_format($stats['totalOrders']) }}</p>
                <p class="card-subtitle">Today: {{ $stats['ordersToday'] }} | This Week: {{ $stats['ordersThisWeek'] }}</p>
            </div>
        </div>

        <div class="card card-orange">
            <div class="card-icon card-icon-clock" aria-hidden="true"></div>
            <div class="card-content">
                <h3>Pending Jobs</h3>
                <p class="card-value">{{ $stats['pendingJobs'] }}</p>
                <p class="card-subtitle">Requires attention</p>
            </div>
        </div>

        <div class="card card-purple">
            <div class="card-icon card-icon-factory" aria-hidden="true"></div>
            <div class="card-content">
                <h3>In Production</h3>
                <p class="card-value">{{ $stats['inProduction'] }}</p>
                <p class="card-subtitle">Currently processing</p>
            </div>
        </div>

        <div class="card card-green">
            <div class="card-icon card-icon-check" aria-hidden="true"></div>
            <div class="card-content">
                <h3>Shipped Orders</h3>
                <p class="card-value">{{ $stats['shippedThisMonth'] }}</p>
                <p class="card-subtitle">This month</p>
            </div>
        </div>

        <div class="card card-red">
            <div class="card-icon card-icon-alert" aria-hidden="true"></div>
            <div class="card-content">
                <h3>Exceptions</h3>
                <p class="card-value">{{ $stats['exceptions'] }}</p>
                <p class="card-subtitle">Requires action</p>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="charts-grid">
        <div class="chart-card">
            <h3>Orders Per Day</h3>
            <canvas id="ordersChart"></canvas>
        </div>

        <div class="chart-card">
            <h3>Orders Per Store</h3>
            <canvas id="storesChart"></canvas>
        </div>

        <div class="chart-card">
            <h3>Apparel vs DTF Jobs</h3>
            <canvas id="productTypeChart"></canvas>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="activity-section">
        <h2>Recent Activity</h2>
        <div class="activity-list">
            @forelse($recentActivity as $activity)
                <div class="activity-item">
                    <div class="activity-icon status-{{ strtolower($activity->action) }}">{{ substr($activity->action, 0, 1) }}</div>
                    <div class="activity-content">
                        <p>
                            <strong>{{ $activity->model_type }}#{{ $activity->model_id }}</strong> -
                            {{ $activity->action }}
                            @if($activity->user)
                                by {{ $activity->user->name }}
                            @endif
                        </p>
                        <span class="activity-time">{{ $activity->created_at->diffForHumans() }}</span>
                    </div>
                </div>
            @empty
                <div class="activity-item">
                    <p>No recent activity</p>
                </div>
            @endforelse
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Orders per day chart
        const ordersCtx = document.getElementById('ordersChart').getContext('2d');
        new Chart(ordersCtx, {
            type: 'line',
            data: {
                labels: {!! json_encode($ordersByDay->pluck('label')) !!},
                datasets: [{
                    label: 'Orders',
                    data: {!! json_encode($ordersByDay->pluck('count')) !!},
                    borderColor: '#3B82F6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Orders per store chart
        const storesCtx = document.getElementById('storesChart').getContext('2d');
        new Chart(storesCtx, {
            type: 'bar',
            data: {
                labels: {!! json_encode($ordersByShop->pluck('shop_domain')) !!},
                datasets: [{
                    label: 'Orders',
                    data: {!! json_encode($ordersByShop->pluck('count')) !!},
                    backgroundColor: [
                        '#3B82F6',
                        '#10B981',
                        '#F59E0B',
                        '#EF4444',
                        '#8B5CF6'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Job types distribution chart
        const jobTypesCtx = document.getElementById('productTypeChart').getContext('2d');
        new Chart(jobTypesCtx, {
            type: 'doughnut',
            data: {
                labels: {!! json_encode($jobTypeDistribution->pluck('job_type')) !!},
                datasets: [{
                    data: {!! json_encode($jobTypeDistribution->pluck('count')) !!},
                    backgroundColor: [
                        '#3B82F6',
                        '#10B981',
                        '#F59E0B',
                        '#EF4444',
                        '#8B5CF6',
                        '#EC4899'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    }
                }
            }
        });
    </script>
@endsection
